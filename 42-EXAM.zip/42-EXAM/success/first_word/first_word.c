/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   first_word.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: guisanto <guisanto@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/03 11:11:47 by guisanto          #+#    #+#             */
/*   Updated: 2025/03/03 13:24:19 by guisanto         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void first_word(char *str)
{
    int i = 0;

    while(str[i] == ' ' || str[i] >= 9 && str[i] <= 13)
        i++;
    while(str[i] >= 33 && str[i] <= 126)
    {
        write(1, &str[i], 1);
        i++;
    }
}
int main(int ac, char **av)
{
    if (ac == 2)
        first_word(av[1]);
    write(1, "\n", 1);
}