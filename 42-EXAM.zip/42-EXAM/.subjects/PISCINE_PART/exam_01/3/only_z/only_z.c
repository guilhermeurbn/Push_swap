#include <unistd.h>

int		main(void)
{
	write(1, "z", 1);
	return (0);
}
